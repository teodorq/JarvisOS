from pathlib import Path
from typing import Optional

from app.autodev.developer_executor import (
    DeveloperExecutor
)
from app.autodev.developer_request import (
    DeveloperRequest
)
from app.autodev.developer_session import (
    DeveloperSession
)
from app.autodev.patch_generator import (
    PatchGenerator
)
from app.autodev.patch_preview import (
    PatchPreview
)
from app.autodev.transaction_builder import (
    TransactionBuilder
)
from app.autodev.workflow_result import (
    WorkflowResult
)


class DeveloperController:

    def __init__(
        self,
        project_root: str = "C:/JarvisAI"
    ):
        self.project_root = Path(
            project_root
        )

        self.patch_generator = (
            PatchGenerator()
        )

        self.transaction_builder = (
            TransactionBuilder()
        )

        self.patch_preview = (
            PatchPreview()
        )

        self.executor = DeveloperExecutor(
            project_root=project_root
        )

        self.session = DeveloperSession()

        self.last_request: Optional[
            DeveloperRequest
        ] = None

        self.last_result: Optional[
            WorkflowResult
        ] = None

    def prepare(
        self,
        request: DeveloperRequest
    ) -> WorkflowResult:

        self.last_request = request

        request_valid, request_errors = (
            request.validate()
        )

        if not request_valid:
            result = WorkflowResult(
                success=False,
                status="request_invalid",
                message=(
                    "Żądanie developerskie "
                    "jest niepoprawne."
                ),
                errors=request_errors
            )

            self.last_result = result
            return result

        self.session.start(
            goal=request.goal,
            target=request.target
        )

        try:
            transaction, errors = (
                self._build_transaction(
                    request
                )
            )

        except Exception as error:
            self.session.mark_failed(
                str(error)
            )

            result = WorkflowResult(
                success=False,
                status="prepare_failed",
                message=(
                    "Nie udało się przygotować "
                    "transakcji zmian."
                ),
                errors=[
                    str(error)
                ]
            )

            self.last_result = result
            return result

        if transaction is None:
            self.session.mark_failed(
                "Generator nie utworzył transakcji."
            )

            result = WorkflowResult(
                success=False,
                status="patch_generation_failed",
                message=(
                    "Nie udało się wygenerować "
                    "patcha."
                ),
                errors=errors
            )

            self.last_result = result
            return result

        transaction_valid, transaction_errors = (
            transaction.validate()
        )

        if not transaction_valid:
            transaction.mark_failed()

            for error in transaction_errors:
                self.session.add_note(
                    error
                )

            self.session.mark_failed(
                "Transakcja nie przeszła walidacji."
            )

            result = WorkflowResult(
                success=False,
                status="transaction_invalid",
                message=(
                    "Wygenerowana transakcja "
                    "jest niepoprawna."
                ),
                transaction=transaction,
                errors=transaction_errors
            )

            self.last_result = result
            return result

        if request.metadata:
            transaction.metadata.update(
                request.metadata
            )

        transaction.metadata[
            "request_mode"
        ] = request.mode

        self.session.set_transaction(
            transaction
        )

        preview = self.patch_preview.build(
            transaction
        )

        result = WorkflowResult(
            success=True,
            status="waiting_for_approval",
            message=(
                "Patch został przygotowany. "
                "Wymagana jest akceptacja."
            ),
            preview=preview,
            transaction=transaction,
            data={
                "goal": request.goal,
                "target": request.target,
                "mode": request.mode,
                "files": transaction.files(),
                "files_count": len(
                    transaction.changes
                )
            }
        )

        self.last_result = result
        return result

    def approve(
        self
    ) -> WorkflowResult:

        if not self.session.has_transaction():
            result = WorkflowResult(
                success=False,
                status="nothing_to_approve",
                message=(
                    "Brak przygotowanej "
                    "transakcji do zatwierdzenia."
                ),
                errors=[
                    "Najpierw wykonaj prepare()."
                ]
            )

            self.last_result = result
            return result

        if self.session.status != (
            "waiting_for_approval"
        ):
            result = WorkflowResult(
                success=False,
                status="approval_not_available",
                message=(
                    "Aktualny stan sesji "
                    "nie pozwala na akceptację."
                ),
                transaction=self.session.transaction,
                errors=[
                    (
                        "Status sesji: "
                        f"{self.session.status}"
                    )
                ]
            )

            self.last_result = result
            return result

        approved = self.session.approve()

        if not approved:
            result = WorkflowResult(
                success=False,
                status="approval_failed",
                message=(
                    "Nie udało się zatwierdzić "
                    "transakcji."
                ),
                errors=[
                    "DeveloperSession odrzuciła akceptację."
                ]
            )

            self.last_result = result
            return result

        result = WorkflowResult(
            success=True,
            status="approved",
            message=(
                "Transakcja została "
                "zatwierdzona."
            ),
            transaction=self.session.transaction,
            data={
                "can_execute": (
                    self.session.can_execute()
                )
            }
        )

        self.last_result = result
        return result

    def execute(
        self,
        auto_rollback: bool = True
    ) -> WorkflowResult:

        if not self.session.can_execute():
            result = WorkflowResult(
                success=False,
                status="execution_blocked",
                message=(
                    "Transakcja nie została "
                    "zatwierdzona."
                ),
                transaction=self.session.transaction,
                errors=[
                    (
                        "Wymagany status sesji: "
                        "approved."
                    ),
                    (
                        "Aktualny status sesji: "
                        f"{self.session.status}"
                    )
                ]
            )

            self.last_result = result
            return result

        transaction = self.session.transaction

        if transaction is None:
            result = WorkflowResult(
                success=False,
                status="missing_transaction",
                message=(
                    "Brak transakcji "
                    "do wykonania."
                ),
                errors=[
                    "DeveloperSession nie posiada transakcji."
                ]
            )

            self.last_result = result
            return result

        self.session.mark_executing()

        try:
            execution_result = (
                self.executor.execute(
                    transaction=transaction,
                    auto_rollback=auto_rollback
                )
            )

        except Exception as error:
            self.session.mark_failed(
                str(error)
            )

            result = WorkflowResult(
                success=False,
                status="execution_exception",
                message=(
                    "Wystąpił wyjątek podczas "
                    "wykonywania zmian."
                ),
                transaction=transaction,
                errors=[
                    str(error)
                ]
            )

            self.last_result = result
            return result

        if execution_result.success:
            self.session.mark_completed()

            result = WorkflowResult(
                success=True,
                status="completed",
                message=(
                    "Workflow AutoDev został "
                    "zakończony powodzeniem."
                ),
                transaction=transaction,
                execution_result=execution_result,
                data={
                    "changed_files": (
                        transaction.files()
                    ),
                    "backup_bundle": (
                        transaction.backup_bundle_path
                    ),
                    "rollback_used": False
                }
            )

            self.last_result = result
            return result

        rollback_data = (
            execution_result.data.get(
                "rollback",
                {}
            )
        )

        rollback_success = (
            rollback_data.get(
                "success",
                False
            )
            if isinstance(
                rollback_data,
                dict
            )
            else False
        )

        if rollback_success:
            self.session.mark_rolled_back()

            status = (
                "failed_and_rolled_back"
            )

            message = (
                "Walidacja lub zapis zmian "
                "nie powiodły się. "
                "Pliki zostały przywrócone."
            )

        else:
            self.session.mark_failed(
                execution_result.message
            )

            status = "failed"

            message = (
                "Workflow AutoDev "
                "nie powiódł się."
            )

        result = WorkflowResult(
            success=False,
            status=status,
            message=message,
            transaction=transaction,
            execution_result=execution_result,
            errors=execution_result.errors,
            data={
                "rollback_attempted": (
                    bool(rollback_data)
                ),
                "rollback_success": (
                    rollback_success
                ),
                "backup_bundle": (
                    transaction.backup_bundle_path
                )
            }
        )

        self.last_result = result
        return result

    def approve_and_execute(
        self,
        auto_rollback: bool = True
    ) -> WorkflowResult:

        approval_result = self.approve()

        if not approval_result.success:
            return approval_result

        return self.execute(
            auto_rollback=auto_rollback
        )

    def reject(
        self,
        reason: str = ""
    ) -> WorkflowResult:

        transaction = self.session.transaction

        if transaction is None:
            result = WorkflowResult(
                success=False,
                status="nothing_to_reject",
                message=(
                    "Brak transakcji "
                    "do odrzucenia."
                ),
                errors=[
                    "Nie przygotowano patcha."
                ]
            )

            self.last_result = result
            return result

        if reason:
            self.session.add_note(
                f"Odrzucono: {reason}"
            )

        self.session.cancel()

        result = WorkflowResult(
            success=True,
            status="rejected",
            message=(
                "Patch został odrzucony. "
                "Żaden plik nie został zmieniony."
            ),
            transaction=transaction,
            data={
                "reason": reason
            }
        )

        self.last_result = result
        return result

    def rollback_last(
        self
    ) -> WorkflowResult:

        rollback_result = (
            self.executor.rollback_last()
        )

        transaction = (
            self.executor.last_transaction
        )

        if rollback_result.success:
            self.session.mark_rolled_back()

            result = WorkflowResult(
                success=True,
                status="rolled_back",
                message=(
                    "Ostatnia transakcja "
                    "została cofnięta."
                ),
                transaction=transaction,
                execution_result=rollback_result
            )

            self.last_result = result
            return result

        self.session.mark_failed(
            rollback_result.message
        )

        result = WorkflowResult(
            success=False,
            status="rollback_failed",
            message=(
                "Nie udało się cofnąć "
                "ostatniej transakcji."
            ),
            transaction=transaction,
            execution_result=rollback_result,
            errors=rollback_result.errors
        )

        self.last_result = result
        return result

    def current_preview(
        self
    ) -> str:

        transaction = self.session.transaction

        if transaction is None:
            return (
                "Brak aktywnej transakcji "
                "do pokazania."
            )

        return self.patch_preview.build(
            transaction
        )

    def status(
        self
    ) -> dict:

        transaction = self.session.transaction

        return {
            "session_status": (
                self.session.status
            ),
            "approved": (
                self.session.approved
            ),
            "has_transaction": (
                transaction is not None
            ),
            "transaction_status": (
                transaction.status
                if transaction
                else ""
            ),
            "goal": self.session.goal,
            "target": self.session.target,
            "can_execute": (
                self.session.can_execute()
            )
        }

    def report(
        self
    ) -> str:

        lines = [
            "AUTODEV DEVELOPER CONTROLLER",
            "",
            self.session.summary()
        ]

        if self.last_request is not None:
            lines.append("")
            lines.append(
                self.last_request.summary()
            )

        if self.last_result is not None:
            lines.append("")
            lines.append(
                self.last_result.summary()
            )

        return "\n".join(lines)

    def reset(
        self
    ):
        self.session = DeveloperSession()
        self.last_request = None
        self.last_result = None

    def _build_transaction(
        self,
        request: DeveloperRequest
    ):

        if request.mode == "file":
            return (
                self.patch_generator
                .build_file_patch(
                    goal=request.goal,
                    target=request.target,
                    path=request.path,
                    proposed_content=(
                        request.proposed_content
                    )
                )
            )

        if request.mode == "function":
            return (
                self.patch_generator
                .build_function_patch(
                    goal=request.goal,
                    target=request.target,
                    path=request.path,
                    function_name=(
                        request.function_name
                    ),
                    new_function_code=(
                        request.new_function_code
                    )
                )
            )

        if request.mode == "multi_file":
            transaction = (
                self.transaction_builder
                .build_multi_file_replacement(
                    goal=request.goal,
                    target=request.target,
                    replacements=(
                        request.replacements
                    )
                )
            )

            return transaction, []

        return (
            None,
            [
                (
                    "Nieobsługiwany tryb "
                    f"żądania: {request.mode}"
                )
            ]
        )