from pathlib import Path

from app.autodev.backup_bundle import BackupBundleManager
from app.autodev.change_transaction import ChangeTransaction
from app.autodev.developer_validator import DeveloperValidator
from app.autodev.execution_result import ExecutionResult
from app.autodev.rollback_manager import RollbackManager


class DeveloperExecutor:

    def __init__(self, project_root="C:/JarvisAI"):
        self.project_root = Path(project_root)

        self.backups = BackupBundleManager()
        self.validator = DeveloperValidator(
            project_root=project_root
        )
        self.rollback_manager = RollbackManager()

        self.last_transaction = None

    def execute(
        self,
        transaction: ChangeTransaction,
        auto_rollback: bool = True
    ) -> ExecutionResult:

        self.last_transaction = transaction

        valid, validation_errors = transaction.validate()

        if not valid:
            transaction.mark_failed()

            return ExecutionResult(
                success=False,
                step_name="transaction_validation",
                message="Transakcja jest niepoprawna.",
                data={
                    "transaction": transaction.summary()
                },
                errors=validation_errors
            )

        backup_result = self._create_backup(
            transaction
        )

        if not backup_result.success:
            transaction.mark_failed()
            return backup_result

        apply_result = self._apply_changes(
            transaction
        )

        if not apply_result.success:
            if auto_rollback:
                rollback_result = (
                    self.rollback_manager.rollback(
                        transaction
                    )
                )

                apply_result.data["rollback"] = (
                    rollback_result.as_dict()
                )

            return apply_result

        validation_result = self._validate_transaction(
            transaction
        )

        if not validation_result.success:
            if auto_rollback:
                rollback_result = (
                    self.rollback_manager.rollback(
                        transaction
                    )
                )

                validation_result.data["rollback"] = (
                    rollback_result.as_dict()
                )

            return validation_result

        transaction.mark_validated()

        return ExecutionResult(
            success=True,
            step_name="developer_executor",
            message=(
                "Zmiany zostały zapisane "
                "i przeszły walidację."
            ),
            data={
                "transaction": transaction.summary(),
                "backup_bundle": (
                    transaction.backup_bundle_path
                ),
                "changed_files": transaction.files()
            }
        )

    def rollback_last(self) -> ExecutionResult:
        if self.last_transaction is None:
            return ExecutionResult(
                success=False,
                step_name="rollback_last",
                message=(
                    "Brak ostatniej transakcji "
                    "do cofnięcia."
                ),
                errors=[
                    "Nie wykonano jeszcze żadnej transakcji."
                ]
            )

        return self.rollback_manager.rollback(
            self.last_transaction
        )

    def preview(
        self,
        transaction: ChangeTransaction
    ) -> str:

        lines = [
            "AUTODEV TRANSACTION PREVIEW",
            f"Cel: {transaction.goal}",
            f"Target: {transaction.target or 'brak'}",
            f"Pliki: {len(transaction.changes)}",
            ""
        ]

        for change in transaction.changes:
            lines.append(
                f"PLIK: {change.path}"
            )
            lines.append("")
            lines.append("STARA WERSJA:")
            lines.append(change.old_content)
            lines.append("")
            lines.append("NOWA WERSJA:")
            lines.append(change.new_content)
            lines.append("")
            lines.append("=" * 60)

        return "\n".join(lines)

    def _create_backup(
        self,
        transaction: ChangeTransaction
    ) -> ExecutionResult:

        manifest = self.backups.create_bundle(
            files=transaction.files(),
            goal=transaction.goal
        )

        bundle_path = manifest.get(
            "bundle_path",
            ""
        )

        files = manifest.get(
            "files",
            []
        )

        errors = manifest.get(
            "errors",
            []
        )

        if errors or len(files) != len(transaction.changes):
            return ExecutionResult(
                success=False,
                step_name="create_backup",
                message=(
                    "Nie udało się przygotować "
                    "pełnego backupu."
                ),
                data={
                    "bundle_path": bundle_path,
                    "backed_up_files": len(files),
                    "expected_files": len(
                        transaction.changes
                    )
                },
                errors=errors or [
                    "Nie wszystkie pliki zostały zapisane."
                ]
            )

        transaction.mark_backed_up(
            bundle_path
        )

        return ExecutionResult(
            success=True,
            step_name="create_backup",
            message="Utworzono backup transakcji.",
            data={
                "bundle_path": bundle_path,
                "files_count": len(files)
            }
        )

    def _apply_changes(
        self,
        transaction: ChangeTransaction
    ) -> ExecutionResult:

        transaction.mark_applying()
        changed_files = []

        for change in transaction.changes:
            file_path = Path(change.path)

            try:
                current_content = file_path.read_text(
                    encoding="utf-8"
                )

                if current_content != change.old_content:
                    change.status = "failed"
                    change.error = (
                        "Zawartość pliku zmieniła się "
                        "od momentu utworzenia planu."
                    )

                    transaction.mark_failed()

                    return ExecutionResult(
                        success=False,
                        step_name="apply_changes",
                        message=(
                            "Przerwano zapis zmian."
                        ),
                        data={
                            "changed_files": changed_files,
                            "failed_file": change.path
                        },
                        errors=[
                            change.error
                        ]
                    )

                file_path.write_text(
                    change.new_content,
                    encoding="utf-8"
                )

                change.status = "applied"
                changed_files.append(
                    change.path
                )

            except Exception as error:
                change.status = "failed"
                change.error = str(error)
                transaction.mark_failed()

                return ExecutionResult(
                    success=False,
                    step_name="apply_changes",
                    message=(
                        "Nie udało się zapisać zmian."
                    ),
                    data={
                        "changed_files": changed_files,
                        "failed_file": change.path
                    },
                    errors=[
                        str(error)
                    ]
                )

        transaction.mark_applied()

        return ExecutionResult(
            success=True,
            step_name="apply_changes",
            message="Zapisano wszystkie zmiany.",
            data={
                "changed_files": changed_files
            }
        )

    def _validate_transaction(
        self,
        transaction: ChangeTransaction
    ) -> ExecutionResult:

        files_result = self.validator.validate_files(
            transaction.files()
        )

        if not files_result.success:
            transaction.mark_failed()
            return files_result

        import_result = self.validator.run_import_test()

        if not import_result.success:
            transaction.mark_failed()
            return import_result

        return ExecutionResult(
            success=True,
            step_name="validate_transaction",
            message=(
                "Walidacja transakcji "
                "zakończona powodzeniem."
            ),
            data={
                "files": files_result.as_dict(),
                "imports": import_result.as_dict()
            }
        )