from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional

from app.autodev.change_transaction import ChangeTransaction


@dataclass
class DeveloperSession:

    goal: str = ""
    target: str = ""
    status: str = "idle"
    approved: bool = False

    transaction: Optional[
        ChangeTransaction
    ] = None

    notes: list[str] = field(
        default_factory=list
    )

    created_at: str = field(
        default_factory=lambda: datetime.now().isoformat()
    )

    updated_at: str = field(
        default_factory=lambda: datetime.now().isoformat()
    )

    def start(
        self,
        goal: str,
        target: str = ""
    ):
        self.goal = goal
        self.target = target
        self.status = "planning"
        self.approved = False
        self.transaction = None
        self.notes = []
        self._touch()

    def set_transaction(
        self,
        transaction: ChangeTransaction
    ):
        self.transaction = transaction
        self.status = "waiting_for_approval"
        self.approved = False
        self._touch()

    def approve(self):
        if self.transaction is None:
            return False

        self.approved = True
        self.status = "approved"
        self._touch()

        return True

    def mark_executing(self):
        self.status = "executing"
        self._touch()

    def mark_completed(self):
        self.status = "completed"
        self._touch()

    def mark_failed(
        self,
        error: str = ""
    ):
        self.status = "failed"

        if error:
            self.notes.append(error)

        self._touch()

    def mark_rolled_back(self):
        self.status = "rolled_back"
        self._touch()

    def cancel(self):
        self.status = "cancelled"
        self.approved = False
        self.transaction = None
        self._touch()

    def add_note(
        self,
        note: str
    ):
        if note:
            self.notes.append(note)
            self._touch()

    def has_transaction(self) -> bool:
        return self.transaction is not None

    def can_execute(self) -> bool:
        return (
            self.transaction is not None
            and self.approved
            and self.status == "approved"
        )

    def summary(self) -> str:
        lines = [
            "DEVELOPER SESSION",
            f"Cel: {self.goal or 'brak'}",
            f"Target: {self.target or 'brak'}",
            f"Status: {self.status}",
            f"Zatwierdzona: {self.approved}",
            f"Transakcja: "
            f"{'TAK' if self.transaction else 'NIE'}",
            f"Utworzono: {self.created_at}",
            f"Zaktualizowano: {self.updated_at}"
        ]

        if self.transaction:
            lines.append("")
            lines.append(
                self.transaction.summary()
            )

        if self.notes:
            lines.append("")
            lines.append("Notatki:")

            for note in self.notes[-20:]:
                lines.append(f"- {note}")

        return "\n".join(lines)

    def _touch(self):
        self.updated_at = (
            datetime.now().isoformat()
        )